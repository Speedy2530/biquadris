# Biquadris Game

**Biquadris** is a two-player Tetris-inspired game developed in C++ with both graphical and text-based interfaces. This game was created as a project for CS246 Fall 2024.

## Contributors
   
   - **Amitpal Badhan** - as3badha@uwaterloo.ca
   - **Shrey Varma** - s3varma@uwaterloo.ca
   - **Saihej Singh** - s268sing@uwaterloo.ca

---
If you have any questions or feedback, please reach out to the contributors listed above.
